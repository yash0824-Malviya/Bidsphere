# RFQ CLM schema patches

Use with the matching bidsphere_workflows app and BidSphere application.
Install the app on the verified production site first. Follow the app README for migration order.
These scripts default to read-only. Inspect --check before --apply and retain the scratch backups.
Use Node.js with built-in fetch support and existing server-only ERPNEXT_URL, ERP_API_KEY and ERP_API_SECRET environment variables.
Credentials are not included. No script runs on extraction.
