# RFQ contract decision transaction

This small Frappe app supplies one transaction endpoint and two document guards.
It reuses the existing Request for Quotation, Contract Request, Contract and
Legal Document Review records. It adds no DocTypes, roles or workflow states.

## Deployment prerequisite

The inspected ERP site runs Frappe 16.20.0 / ERPNext 16.22.0 and has Server Scripts
disabled. Storing a Server Script will not make this endpoint available. Deploy
this app through the ERP administrator's normal Bench deployment process;
the frontend/serverless repository cannot install a Python module over REST.
Do not enable all Server Scripts as a workaround.

1. Back up the site using its normal operational procedure.
2. Choose either the packaged local source route below or your normal reviewed
   Git app deployment. For the local source route, extract this app directory as
   `<bench>/apps/bidsphere_workflows` (do not overwrite an existing installation),
   then run from the Bench root:

   ```sh
   bench pip install -e apps/bidsphere_workflows
   ./env/bin/python apps/bidsphere_workflows/register_on_bench.py
   ./env/bin/python apps/bidsphere_workflows/register_on_bench.py --apply
   ```

   The registration helper verifies its directory, preserves and backs up
   `sites/apps.txt`, then appends only this app if absent. No site data is touched.
   This source-only app has no assets or Node dependencies to build.

   For the Git route instead, package this directory as its own reviewed Git app
   repository and run `bench get-app <reviewed-bidsphere-workflows-git-url>`.
   A copied folder without Git metadata is not a valid `bench get-app` source.
   Both routes then use the standard site installer:

   ```sh
   bench --site <site> install-app bidsphere_workflows
   bench --site <site> set-config bidsphere_gateway_user <existing-service-user>
   bench --site <site> migrate
   bench restart
   ```

   `bidsphere_gateway_user` must be the ERP user owning the existing server-side
   BidSphere API credential. Prefer a dedicated service identity. Do not give
   its credential to browser clients. No account or permission changes are
   made by this app. The identity must already have normal RFQ write and
   Contract Request create permissions.

   For an existing reviewed **local Git working tree**, the Git URL can be its
   absolute path. Keep that app root named `bidsphere_workflows`. The package has
   its own `pyproject.toml`, Frappe `hooks.py`, `modules.txt` and `patches.txt`.
   It declares Frappe/ERPNext v16 dependencies and contains no new DocTypes.

   The local route follows Bench's editable package installation and Frappe's
   app registry requirement ([Bench installer source](https://github.com/frappe/bench/blob/develop/bench/app.py),
   [Frappe v16 installer source](https://github.com/frappe/frappe/blob/version-16/frappe/installer.py)).
   It has been checked against those sources; host deployment is still required.

3. From the BidSphere repository, inspect and apply the narrow schema patch:

   ```sh
   node scripts/setup-rfq-clm-branch.mjs --check
   node scripts/setup-rfq-clm-branch.mjs --apply
   node scripts/setup-rfq-award-contract.mjs --check
   node scripts/setup-rfq-award-contract.mjs --apply
   ```

   This changes only `contract_required.allow_on_submit` to `1`, allowing an
   authorized decision on a submitted RFQ. It retains Yes/No, required/default
   rules, all existing records, roles and permissions. Existing CLM schema and
   the unique `Contract Request.custom_rfq` constraint must already be present.
   The script saves before/after schema and record evidence under `scratch`.
   The award-form patch appends missing contract type choices to existing CLM
   fields, retaining all legacy choices, defaults, records and permissions.
   New RFQ award requests must explicitly supply their type, purpose,
   description, department, dates and `legal_review_required: 1`. The transaction
   validates these fields and their persisted values before committing.

4. Deploy the matching BidSphere Node/API/frontend changes and run the acceptance
   steps below before declaring the branch ready.

## Endpoint contract

`POST /api/method/bidsphere_workflows.rfq_clm.decide`

The secured Node endpoint derives `actor` from its authenticated session and
prepares the existing CLM draft using `applyClmAction`. It sends:

```json
{
  "rfq": "RFQ-ID",
  "expected_modified": "exact ERP timestamp",
  "decision": "Yes",
  "actor": {"id": "authenticated-user", "role": "procurement"},
  "award": {
    "quotation": "SQ-ID",
    "quotation_modified": "exact ERP timestamp",
    "legal_review": "REVIEW-ID",
    "legal_review_modified": "exact ERP timestamp",
    "supplier": "exact Supplier DocName",
    "amount": 100,
    "currency": "USD",
    "business_case": "optional verified case reference",
    "ecr": "optional verified ECR reference"
  },
  "request_document": {"doctype": "Contract Request", "request_status": "Draft"}
}
```

The example request document is abbreviated: Node supplies every required
existing CLM field, source evidence and creation audit. `request_document` is
omitted for No. Legal review keys are absent only when the existing persisted
selection identifies a single submitted winning quotation without a review.
Returns `{created, decision, rfq, request}`; `request` is null for No.

The method locks the RFQ first, checks exact revisions/source identity/award,
inserts one Contract Request, then saves the decision in the RFQ's existing
`custom_approval_data.contract_decision` and `contract_required`. It preserves
the existing RFQ workflow step. Frappe commits after successful POST completion;
any exception rolls back both records. There is no explicit commit or separate
REST update. Row locking plus the existing unique RFQ source constraint protects
duplicate requests across workers. An identical retry returns the recorded
request; an opposite choice is rejected.

## Enforcement and compatibility

- Only the configured ERP gateway identity may invoke the transaction; actor
  role must be procurement/admin, as already verified by Node.
- Native RFQ document saves cannot alter/remove a saved decision or change an
  awarded requirement through the ordinary field path.
- New RFQ-linked POs require a recorded No decision, or the matching Yes CLM
  with an Executed/Active Contract, approved route, current version and both
  signatures. Node also verifies the existing CLM content hash before PO.
- Existing Legal signature and Finance approval guards still apply separately.
- Existing already-created POs with no recorded decision and a No/blank flag
  retain historical edit behavior. A Yes flag is always enforced.
- Existing audited RFQ Contract Requests with an earlier Yes flag retain their
  branch: the guard reads the original source and creation audit, validates the
  current award and executed Contract, and never rewrites their history.
- Standalone PO, supplier invitation, quotation, evaluation, negotiation, legacy
  ECR and Business Intake workflows retain their existing implementation.

## Tests and remaining live acceptance

Portable transaction-model tests (no ERP mutation):

```sh
python -m unittest discover -s erpnext_apps/bidsphere_workflows/tests -v
npx vitest run --config erpnext_apps/bidsphere_workflows/vitest.config.mjs
```

The Python fake explicitly models a whole POST rollback and row serialization;
it does **not** prove deployment, MariaDB locking or real e-signature execution.
After deployment, use approved test RFQs/awards and real test users:

1. On a submitted awarded RFQ choose Yes; re-fetch both records and confirm one
   Contract Request, exact source links, audit and matching RFQ decision.
2. Retry the same action concurrently in two sessions: one request must exist.
3. Inject a controlled test-only RFQ validation failure *after* request insertion
   on a staging site; confirm both the new request and decision are rolled back.
   Remove the test hook before any other testing.
4. Attempt ordinary RFQ field/decision changes and PO creation while CLM is
   pending: both must fail without mutations.
5. Complete the existing CLM request validation, Contract authoring, Legal
   approvals and both signatures as their actual assigned test users. Confirm
   Executed/Active CLM releases only the CLM hold; existing RFQ Legal/Finance
   readiness remains required for PO.
6. On a separate awarded RFQ choose No; confirm no CLM exists and the established
   RFQ Legal/Finance/PO continuation succeeds.
7. Verify supplier and unauthorized internal roles cannot record either choice.

Do not sign a real supplier contract or place a real PO merely to test deployment.
