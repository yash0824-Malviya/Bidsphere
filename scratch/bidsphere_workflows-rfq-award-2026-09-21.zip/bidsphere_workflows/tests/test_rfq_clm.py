"""Portable behavior tests. A transactional fake models Frappe POST rollback.

These are not a substitute for the live database/lock acceptance checklist in
README.md. They run without installing Frappe on the frontend workstation.
"""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime
import importlib.util
import json
from pathlib import Path
import sys
import threading
import types
import unittest


class ValidationError(Exception):
    pass


class PermissionError(Exception):
    pass


class Document(dict):
    def __getattr__(self, key):
        return self.get(key)

    def __setattr__(self, key, value):
        if key.startswith("_"):
            return object.__setattr__(self, key, value)
        self[key] = value

    def as_dict(self):
        return deepcopy(dict(self))

    def check_permission(self, kind):
        if not STORE.allowed:
            raise PermissionError("ERP write permission denied")

    def insert(self):
        if STORE.fail_insert:
            raise ValidationError("Contract Request validation failed")
        if self.get("doctype") == "Contract Request" and any(row.get("custom_rfq") == self.get("custom_rfq") for (dt, _), row in STORE.docs.items() if dt == "Contract Request"):
            raise ValidationError("Duplicate RFQ source")
        self["name"] = "CR-1"
        self["modified"] = "cr1"
        STORE.put(self)
        return self

    def save(self):
        if self["doctype"] == "Request for Quotation":
            subject.guard_rfq(self)
            if STORE.fail_rfq_save:
                raise ValidationError("RFQ validation failed after request insertion")
        self["modified"] = "r2"
        STORE.put(self)
        return self

    def get_doc_before_save(self):
        value = STORE.docs.get((self.get("doctype"), self.get("name")))
        return Document(deepcopy(value)) if value else None


class Store:
    def __init__(self):
        self.docs = {}
        self.allowed = True
        self.fail_insert = False
        self.fail_rfq_save = False
        self.unique = True
        self.drop_fields = {}
        self.locks = []
        self.lock = threading.RLock()

    def put(self, document):
        stored = deepcopy(dict(document))
        for field in self.drop_fields.get(document["doctype"], []):
            stored.pop(field, None)
        self.docs[(document["doctype"], document["name"])] = stored

    def load(self, doctype, name=None, for_update=False):
        if isinstance(doctype, dict):
            return Document(deepcopy(doctype))
        if for_update:
            self.locks.append((doctype, name))
        return Document(deepcopy(self.docs[(doctype, name)]))

    def list(self, doctype, filters=None, pluck=None):
        rows = [row for (dt, _), row in self.docs.items() if dt == doctype]
        if isinstance(filters, dict):
            rows = [row for row in rows if all(row.get(key) == value for key, value in filters.items())]
        elif filters:
            for clause in filters:
                if len(clause) == 4:
                    _, field, op, value = clause
                    rows = [row for row in rows if any(child.get(field) == value for child in row.get("items", []))]
                else:
                    field, op, value = clause
                    rows = [row for row in rows if (row.get(field) != value if op == "!=" else row.get(field) == value)]
        return [row[pluck] for row in rows]

    @contextmanager
    def transaction(self):
        # Models Frappe's one POST transaction and RFQ FOR UPDATE serialization.
        with self.lock:
            before = deepcopy(self.docs)
            try:
                yield
            except Exception:
                self.docs = before
                raise


STORE = Store()
frappe = types.ModuleType("frappe")
frappe.ValidationError = ValidationError
frappe.PermissionError = PermissionError
frappe.whitelist = lambda **kwargs: lambda fn: fn
frappe.throw = lambda message, exc=ValidationError: (_ for _ in ()).throw(exc(message))
frappe.get_doc = lambda *args, **kwargs: STORE.load(*args, **kwargs)
frappe.get_all = lambda *args, **kwargs: STORE.list(*args, **kwargs)
frappe.get_meta = lambda dt: types.SimpleNamespace(get_field=lambda name: types.SimpleNamespace(unique=STORE.unique))
frappe.db = types.SimpleNamespace(exists=lambda dt, name: (dt, name) in STORE.docs)
frappe.conf = {"bidsphere_gateway_user": "gateway@example.test"}
frappe.session = types.SimpleNamespace(user="gateway@example.test")
frappe.local = threading.local()
utils = types.ModuleType("frappe.utils")
utils.now_datetime = lambda: datetime(2026, 9, 18, 15, 0, 0)
sys.modules["frappe"] = frappe
sys.modules["frappe.utils"] = utils
spec = importlib.util.spec_from_file_location("rfq_clm", Path(__file__).parents[1] / "bidsphere_workflows" / "rfq_clm.py")
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


class RfqClmTests(unittest.TestCase):
    def setUp(self):
        global STORE
        STORE = Store()
        frappe.conf = {"bidsphere_gateway_user": "gateway@example.test"}
        frappe.session.user = "gateway@example.test"
        frappe.local = threading.local()
        STORE.put({"doctype": "Request for Quotation", "name": "RFQ-1", "modified": "r1", "docstatus": 1, "status": "Submitted", "company": "COMPANY", "contract_required": "No", "custom_selected_supplier": "SUP-1", "custom_workflow_step": "Pending Legal Review", "custom_approval_data": json.dumps({"rfq": "RFQ-1", "selected_supplier": "SUP-1", "workflow_step": "Pending Legal Review", "unrelated": "preserved"})})
        STORE.put({"doctype": "Supplier Quotation", "name": "SQ-1", "modified": "q1", "docstatus": 1, "supplier": "SUP-1", "company": "COMPANY", "currency": "USD", "grand_total": 100, "items": [{"request_for_quotation": "RFQ-1"}]})
        STORE.put({"doctype": "Supplier", "name": "SUP-1", "disabled": 0})
        STORE.put({"doctype": "Legal Document Review", "name": "LDR-1", "modified": "l1", "rfq_name": "RFQ-1", "sq_name": "SQ-1", "supplier": "SUP-1", "company": "COMPANY", "grand_total": 95, "workflow_state": "Pending Review"})
        self.actor = {"id": "buyer@example.test", "role": "procurement"}
        self.award = {"quotation": "SQ-1", "quotation_modified": "q1", "legal_review": "LDR-1", "legal_review_modified": "l1", "supplier": "SUP-1", "amount": 95, "currency": "USD", "company": "COMPANY", "department": "Production - COMPANY"}
        self.runtime = json.dumps({"schema": 1, "approvals": [], "versions": [], "signatures": [], "sla": [], "audit": [{"action": "create", "by": self.actor["id"], "at": "2026-09-18 15:00:00"}], "rfq_source": {"rfq": "RFQ-1", "quotation": "SQ-1", "award": "LDR-1", "supplier": "SUP-1", "contract_required": True, "company": "COMPANY", "department": "Production - COMPANY", "amount": 95, "currency": "USD"}, "source_documents": []})
        self.request = {"doctype": "Contract Request", "custom_rfq": "RFQ-1", "custom_supplier_quotation": "SQ-1", "supplier": "SUP-1", "company": "COMPANY", "currency": "USD", "contract_value": 95, "estimated_contract_value": 95, "request_status": "Draft", "approval_status": "Pending", "custom_clm_data": self.runtime, "department": "Production - COMPANY", "contract_type": "Supply / Procurement Contract", "contract_purpose": "Procurement from SUP-1 under RFQ-1.", "description": "Awarded procurement of the RFQ-1 items.", "contract_start_date": "2026-09-21", "contract_end_date": "2027-09-21", "legal_review_required": 1}

    def decide(self, decision="Yes", **changes):
        args = {"rfq": "RFQ-1", "expected_modified": "r1", "decision": decision, "actor": self.actor, "award": self.award, "request_document": self.request if decision == "Yes" else None, **changes}
        with STORE.transaction():
            return subject.decide(**args)

    def rfq(self):
        return STORE.load("Request for Quotation", "RFQ-1")

    def po(self, **changes):
        return Document({"doctype": "Purchase Order", "name": "PO-NEW", "supplier": "SUP-1", "items": [{"supplier_quotation": "SQ-1"}], **changes})

    def executed(self):
        STORE.put({"doctype": "Contract", "name": "CON-1", "custom_rfq": "RFQ-1", "custom_contract_request": "CR-1", "custom_supplier_quotation": "SQ-1", "custom_supplier": "SUP-1", "custom_contract_status": "Executed", "custom_esign_status": "Completed", "custom_final_version_locked": 1, "custom_executed_contract": "/private/files/executed.pdf", "custom_current_version": "1.0", "custom_clm_data": json.dumps({"schema": 1, "locked_hash": "c" * 64, "version": "version-uuid", "versions": [{"id": "version-uuid", "number": "1.0", "hash": "b" * 64, "content": {"custom_supplier": "SUP-1"}}], "approvals": [{"status": "Approved"}], "signatures": [{"party": party, "version": "1.0", "file_id": party, "hash": "a" * 64} for party in ["supplier", "inteva"]]})})
        STORE.docs[("Contract", "CON-1")].update({"custom_contract_value": 95, "custom_currency": "USD"})

    def test_yes_inserts_request_and_records_decision_together(self):
        result = self.decide()
        self.assertTrue(result["created"])
        self.assertEqual(result["request"]["custom_clm_data"], self.runtime)
        rfq = self.rfq()
        data = json.loads(rfq.custom_approval_data)
        self.assertEqual(rfq.contract_required, "Yes")
        self.assertEqual(data["contract_decision"]["request"], "CR-1")
        self.assertEqual(data["contract_decision"]["quotation"], "SQ-1")
        self.assertEqual(data["unrelated"], "preserved")
        self.assertEqual(rfq.custom_workflow_step, "Pending Legal Review")
        self.assertEqual(STORE.locks[0], ("Request for Quotation", "RFQ-1"))

    def test_no_records_choice_without_creating_clm_and_allows_existing_path(self):
        result = self.decide("No")
        self.assertFalse(result["created"])
        self.assertIsNone(result["request"])
        self.assertEqual(result["decision"]["decision"], "No")
        subject.guard_purchase_order(self.po())

    def test_new_award_request_requires_explicit_supported_contract_type(self):
        for value in (None, "", " ", "Select Contract Type", "Supplier Agreement", "made-up", []):
            with self.subTest(value=value):
                before = deepcopy(STORE.docs)
                with self.assertRaisesRegex(ValidationError, "Contract Type"):
                    self.decide(request_document={**self.request, "contract_type": value})
                self.assertEqual(STORE.docs, before)
        for value in ("Supply / Procurement Contract", "Service Agreement", "NDA", "Master Service Agreement", "Other"):
            with self.subTest(accepted=value):
                self.setUp()
                result = self.decide(request_document={**self.request, "contract_type": value})
                self.assertEqual(result["request"]["contract_type"], value)

    def test_new_award_request_rejects_blank_purpose_description_and_department(self):
        for field in ("contract_purpose", "description", "department"):
            for value in (None, "", " \n\t ", 123):
                with self.subTest(field=field, value=value):
                    before = deepcopy(STORE.docs)
                    with self.assertRaisesRegex(ValidationError, "is required"):
                        self.decide(request_document={**self.request, field: value})
                    self.assertEqual(STORE.docs, before)

    def test_new_award_request_rejects_nonexistent_malformed_or_reversed_dates(self):
        for field in ("contract_start_date", "contract_end_date"):
            for value in (None, "", "2026-02-30", "2026-13-01", "2026-9-21", "20260921", "2026-09-21T00:00:00Z", 20260921):
                with self.subTest(field=field, value=value):
                    before = deepcopy(STORE.docs)
                    with self.assertRaisesRegex(ValidationError, "valid Contract"):
                        self.decide(request_document={**self.request, field: value})
                    self.assertEqual(STORE.docs, before)
        with self.assertRaisesRegex(ValidationError, "on or after"):
            self.decide(request_document={**self.request, "contract_end_date": "2026-09-20"})
        result = self.decide(request_document={**self.request, "contract_start_date": "2028-02-29", "contract_end_date": "2028-02-29"})
        self.assertEqual(result["request"]["contract_end_date"], "2028-02-29")

    def test_new_award_request_preserves_department_and_context_metadata(self):
        for field, value in (("company", "OTHER"), ("currency", "EUR"), ("amount", 500), ("department", "Other Department")):
            with self.subTest(field=field):
                runtime = json.loads(self.runtime)
                runtime["rfq_source"][field] = value
                before = deepcopy(STORE.docs)
                with self.assertRaises(ValidationError):
                    self.decide(request_document={**self.request, "custom_clm_data": json.dumps(runtime)})
                self.assertEqual(STORE.docs, before)
        with self.assertRaisesRegex(ValidationError, "award department"):
            self.decide(request_document={**self.request, "department": "OTHER"})
        result = self.decide()
        source = json.loads(result["request"]["custom_clm_data"])["rfq_source"]
        self.assertEqual({key: source[key] for key in ("company", "department", "amount", "currency", "award")}, {"company": "COMPANY", "department": "Production - COMPANY", "amount": 95, "currency": "USD", "award": "LDR-1"})

    def test_manual_department_is_preserved_when_award_has_no_department(self):
        award = {**self.award, "department": ""}
        result = self.decide(award=award)
        self.assertEqual(result["request"]["department"], "Production - COMPANY")
        self.assertEqual(json.loads(result["request"]["custom_clm_data"])["rfq_source"]["department"], "Production - COMPANY")

    def test_new_award_request_requires_legal_review_and_detects_dropped_form_fields(self):
        for value in (None, 0, "0"):
            with self.assertRaisesRegex(ValidationError, "Legal Manager review"):
                self.decide(request_document={**self.request, "legal_review_required": value})
        for field in subject._AWARD_FORM_FIELDS:
            with self.subTest(field=field):
                before = deepcopy(STORE.docs)
                STORE.drop_fields = {"Contract Request": [field]}
                with self.assertRaises(ValidationError):
                    self.decide()
                self.assertEqual(STORE.docs, before)
        STORE.drop_fields = {}

    def test_legacy_request_adoption_and_retry_keep_legacy_type_and_details(self):
        legacy = {**self.request, "name": "CR-OLD", "contract_type": "Supplier Agreement", "contract_purpose": "", "contract_start_date": None, "legal_review_required": 0}
        runtime = json.loads(self.runtime)
        for key in ("company", "department", "amount", "currency"):
            runtime["rfq_source"].pop(key)
        legacy["custom_clm_data"] = json.dumps(runtime)
        STORE.put(legacy)
        result = self.decide()
        self.assertFalse(result["created"])
        self.assertEqual(result["request"]["contract_type"], "Supplier Agreement")
        before = deepcopy(STORE.docs)
        retry = self.decide(request_document={"contract_type": ""})
        self.assertFalse(retry["created"])
        self.assertEqual(STORE.docs, before)

    def test_request_validation_failure_rolls_back_yes(self):
        STORE.fail_insert = True
        before = deepcopy(STORE.docs)
        with self.assertRaisesRegex(ValidationError, "Contract Request validation"):
            self.decide()
        self.assertEqual(STORE.docs, before)

    def test_rfq_save_failure_after_insert_rolls_back_request_and_flag(self):
        STORE.fail_rfq_save = True
        before = deepcopy(STORE.docs)
        with self.assertRaisesRegex(ValidationError, "RFQ validation"):
            self.decide()
        self.assertEqual(STORE.docs, before)
        self.assertIsNone(getattr(frappe.local, subject._CONTEXT, None))

    def test_same_choice_retry_ignores_old_revision_and_reuses_request(self):
        self.decide()
        before = deepcopy(STORE.docs)
        result = self.decide()
        self.assertFalse(result["created"])
        self.assertEqual(result["request"]["name"], "CR-1")
        self.assertEqual(STORE.docs, before)

    def test_concurrent_duplicate_posts_create_one_request(self):
        results, errors = [], []
        def run():
            try:
                results.append(self.decide())
            except Exception as error:
                errors.append(error)
        workers = [threading.Thread(target=run) for _ in range(2)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        self.assertEqual(errors, [])
        self.assertEqual(sorted(row["created"] for row in results), [False, True])
        self.assertEqual(len(STORE.list("Contract Request", {}, "name")), 1)

    def test_opposite_choice_cannot_replace_saved_decision(self):
        self.decide("No")
        with self.assertRaisesRegex(ValidationError, "already recorded"):
            self.decide("Yes")

    def test_non_gateway_user_and_unconfigured_service_cannot_call(self):
        frappe.session.user = "Administrator"
        with self.assertRaises(PermissionError):
            self.decide()
        frappe.session.user = "gateway@example.test"
        frappe.conf = {}
        with self.assertRaises(PermissionError):
            self.decide()

    def test_unauthorized_actor_and_native_write_permission_denied(self):
        with self.assertRaises(PermissionError):
            self.decide(actor={"id": "supplier@example.test", "role": "supplier"})
        STORE.allowed = False
        with self.assertRaises(PermissionError):
            self.decide()

    def test_stale_revisions_and_changed_award_do_not_write(self):
        for changes in [{"expected_modified": "old"}, {"award": {**self.award, "quotation_modified": "old"}}, {"award": {**self.award, "legal_review_modified": "old"}}, {"award": {**self.award, "amount": 100}}, {"award": {**self.award, "currency": "EUR"}}]:
            before = deepcopy(STORE.docs)
            with self.assertRaises(ValidationError):
                self.decide(**changes)
            self.assertEqual(STORE.docs, before)

    def test_draft_or_mismatched_quotation_cannot_be_awarded(self):
        STORE.docs[("Supplier Quotation", "SQ-1")]["docstatus"] = 0
        with self.assertRaisesRegex(ValidationError, "submitted"):
            self.decide()

    def test_disabled_supplier_and_missing_unique_constraint_fail(self):
        STORE.docs[("Supplier", "SUP-1")]["disabled"] = 1
        with self.assertRaisesRegex(ValidationError, "Supplier"):
            self.decide()
        STORE.docs[("Supplier", "SUP-1")]["disabled"] = 0
        STORE.unique = False
        with self.assertRaisesRegex(ValidationError, "unique constraint"):
            self.decide()

    def test_preexisting_request_is_adopted_without_duplicate(self):
        STORE.put({**self.request, "name": "CR-OLD", "modified": "cr1"})
        result = self.decide()
        self.assertFalse(result["created"])
        self.assertEqual(result["decision"]["request"], "CR-OLD")

    def test_no_is_rejected_if_clm_exists(self):
        STORE.put({**self.request, "name": "CR-OLD"})
        with self.assertRaisesRegex(ValidationError, "existing CLM"):
            self.decide("No")

    def test_bad_request_source_or_approval_state_is_rejected(self):
        for changes in [{"supplier": "SUP-OTHER"}, {"contract_value": 96}, {"name": "CLIENT-ID"}, {"approval_status": "Approved"}, {"flags": {"ignore_permissions": True}}]:
            with self.assertRaises(ValidationError):
                self.decide(request_document={**self.request, **changes})

    def test_ecr_business_case_trace_is_verified_and_persisted(self):
        STORE.docs[("Request for Quotation", "RFQ-1")]["custom_ecr_reference"] = "ECR-1"
        STORE.put({"doctype": "Engineering Change Request", "name": "ECR-1", "ecr_business_case": json.dumps({"business_case_id": "BC-ECR-1"})})
        award = {**self.award, "ecr": "ECR-1", "business_case": "BC-ECR-1"}
        runtime = json.loads(self.runtime)
        runtime["rfq_source"].update({"ecr": "ECR-1", "business_case": "BC-ECR-1"})
        result = self.decide(award=award, request_document={**self.request, "custom_clm_data": json.dumps(runtime)})
        self.assertEqual(result["decision"]["business_case"], "BC-ECR-1")

    def test_business_case_backlink_is_verified(self):
        STORE.put({"doctype": "Business Case", "name": "BC-1", "rfq_id": "RFQ-OTHER"})
        with self.assertRaisesRegex(ValidationError, "Business Case source"):
            self.decide("No", award={**self.award, "business_case": "BC-1"})
        STORE.docs[("Business Case", "BC-1")]["rfq_id"] = "RFQ-1"
        self.decide("No", award={**self.award, "business_case": "BC-1"})

    def test_direct_flag_or_decision_mutations_are_blocked(self):
        doc = self.rfq()
        doc.contract_required = "Yes"
        with self.assertRaisesRegex(ValidationError, "award decision action"):
            subject.guard_rfq(doc)
        self.decide("No")
        doc = self.rfq()
        data = json.loads(doc.custom_approval_data)
        del data["contract_decision"]
        doc.custom_approval_data = json.dumps(data)
        with self.assertRaisesRegex(ValidationError, "must be preserved"):
            subject.guard_rfq(doc)

    def test_unrelated_rfqs_and_initial_draft_flag_are_unchanged(self):
        new = Document({"doctype": "Request for Quotation", "name": "RFQ-NEW", "contract_required": "Yes"})
        subject.guard_rfq(new)
        doc = self.rfq()
        doc.title = "Revised title"
        subject.guard_rfq(doc)

    def test_pending_or_yes_clm_blocks_po_until_executed(self):
        with self.assertRaisesRegex(ValidationError, "Record Contract"):
            subject.guard_purchase_order(self.po())
        self.decide()
        with self.assertRaisesRegex(ValidationError, "executed Contract"):
            subject.guard_purchase_order(self.po())
        self.executed()
        subject.guard_purchase_order(self.po())

    def test_missing_signature_and_wrong_execution_version_block_po(self):
        self.decide()
        self.executed()
        contract = STORE.docs[("Contract", "CON-1")]
        data = json.loads(contract["custom_clm_data"])
        data["signatures"].pop()
        contract["custom_clm_data"] = json.dumps(data)
        with self.assertRaisesRegex(ValidationError, "both signatures"):
            subject.guard_purchase_order(self.po())

    def test_legacy_existing_po_edit_and_standalone_po_are_unchanged(self):
        existing = self.po(name="PO-OLD")
        STORE.put(existing)
        subject.guard_purchase_order(existing)
        subject.guard_purchase_order(self.po(items=[{"item_code": "ITEM-1"}]))

    def test_legacy_existing_po_with_yes_flag_still_cannot_bypass(self):
        existing = self.po(name="PO-OLD")
        STORE.put(existing)
        STORE.docs[("Request for Quotation", "RFQ-1")]["contract_required"] = "Yes"
        with self.assertRaises(ValidationError):
            subject.guard_purchase_order(existing)

    def test_po_cannot_detach_quotation_or_switch_supplier(self):
        with self.assertRaisesRegex(ValidationError, "Quotation links"):
            subject.guard_purchase_order(self.po(rfq="RFQ-1", items=[{"item_code": "ITEM-1"}]))
        with self.assertRaisesRegex(ValidationError, "awarded supplier"):
            subject.guard_purchase_order(self.po(supplier="SUP-OTHER"))

    def test_schema_omissions_are_detected_inside_transaction_and_rolled_back(self):
        for doctype, field in [("Contract Request", "custom_clm_data"), ("Contract Request", "custom_rfq"), ("Request for Quotation", "custom_approval_data"), ("Request for Quotation", "contract_required")]:
            before = deepcopy(STORE.docs)
            STORE.drop_fields = {doctype: [field]}
            with self.assertRaises(ValidationError):
                self.decide()
            self.assertEqual(STORE.docs, before)
        STORE.drop_fields = {}

    def test_closed_award_round_remains_valid(self):
        STORE.docs[("Request for Quotation", "RFQ-1")]["custom_active_rfq_round"] = "ROUND-1"
        STORE.docs[("Supplier Quotation", "SQ-1")]["custom_rfq_round"] = "ROUND-1"
        STORE.put({"doctype": "RFQ Round", "name": "ROUND-1", "rfq": "RFQ-1", "status": "Closed"})
        self.decide("No")
        subject.guard_purchase_order(self.po())

    def test_changed_award_amount_blocks_no_and_yes_continuation(self):
        self.decide("No")
        STORE.docs[("Legal Document Review", "LDR-1")]["grand_total"] = 96
        with self.assertRaisesRegex(ValidationError, "award amount"):
            subject.guard_purchase_order(self.po())

    def test_wrong_contract_or_request_award_value_blocks_po(self):
        self.decide()
        self.executed()
        STORE.docs[("Contract", "CON-1")]["custom_contract_value"] = 96
        with self.assertRaisesRegex(ValidationError, "award amount"):
            subject.guard_purchase_order(self.po())
        STORE.docs[("Contract", "CON-1")]["custom_contract_value"] = 95
        STORE.docs[("Contract Request", "CR-1")]["contract_value"] = 96
        with self.assertRaisesRegex(ValidationError, "award amount"):
            subject.guard_purchase_order(self.po())

    def test_pending_completion_cannot_bypass_using_any_state_field(self):
        for field in ("status", "workflow_state", "custom_workflow_step"):
            doc = self.rfq()
            doc[field] = "Completed"
            with self.assertRaisesRegex(ValidationError, "Record Contract"):
                subject.guard_rfq(doc)
        doc = self.rfq()
        data = json.loads(doc.custom_approval_data)
        data["workflow_step"] = "Completed"
        doc.custom_approval_data = json.dumps(data)
        with self.assertRaisesRegex(ValidationError, "Record Contract"):
            subject.guard_rfq(doc)

    def test_historical_completion_edits_remain_valid_only_without_clm(self):
        existing = self.po(name="PO-OLD")
        STORE.put(existing)
        STORE.docs[("Request for Quotation", "RFQ-1")]["custom_workflow_step"] = "PO Created"
        doc = self.rfq()
        doc.title = "Corrected title"
        subject.guard_rfq(doc)
        STORE.put({**self.request, "name": "CR-OLD"})
        with self.assertRaises(ValidationError):
            subject.guard_rfq(doc)
        with self.assertRaises(ValidationError):
            subject.guard_purchase_order(existing)

    def test_audited_legacy_yes_clm_can_release_without_rewriting_decision(self):
        STORE.docs[("Request for Quotation", "RFQ-1")]["contract_required"] = "Yes"
        data = json.loads(self.runtime)
        data["rfq_source"]["legal_review"] = "LDR-1"
        STORE.put({**self.request, "name": "CR-1", "custom_clm_data": json.dumps(data)})
        with self.assertRaisesRegex(ValidationError, "executed Contract"):
            subject.guard_purchase_order(self.po())
        self.executed()
        before = deepcopy(STORE.docs)
        subject.guard_purchase_order(self.po())
        self.assertEqual(STORE.docs, before)
        self.assertNotIn("contract_decision", json.loads(self.rfq().custom_approval_data))

    def test_legacy_yes_without_creation_audit_cannot_release(self):
        STORE.docs[("Request for Quotation", "RFQ-1")]["contract_required"] = "Yes"
        data = json.loads(self.runtime)
        data["audit"] = []
        STORE.put({**self.request, "name": "CR-1", "custom_clm_data": json.dumps(data)})
        self.executed()
        with self.assertRaisesRegex(ValidationError, "creation audit"):
            subject.guard_purchase_order(self.po())

    def test_new_rfq_reference_added_to_existing_po_is_not_grandfathered(self):
        STORE.put(self.po(name="PO-OLD", items=[{"item_code": "ITEM-1"}]))
        with self.assertRaisesRegex(ValidationError, "Record Contract"):
            subject.guard_purchase_order(self.po(name="PO-OLD"))


if __name__ == "__main__":
    unittest.main()
